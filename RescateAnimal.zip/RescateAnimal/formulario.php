<?php
$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8", "root", "");
?>
<?php    
    session_start();    
    if(!isset($_SESSION["correo"])){
    die();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registrar Usuario</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style1.css">
</head>
<body style="background-image: url(images/huellas.jpg);">

    <div class="container well" style="margin:0 0 0 300px;color:purple">
		<div class="row">
				<div class="col-xs-12" style="color:red"><h3>ADOPTA UNA MASCOTA </h3></div>
               
            </div>
            <?php foreach ($pdo->query("SELECT * FROM carrito ") as $fila) { ?>
            <td>
            <img style="width:300px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>">
            
            </td>
            <?php } ?>    
		<br /><br />
        <h1>LLENA TUS DATOS PARA EVALUARTE</h1>
        <?php if(isset($_GET["error"])) {?>
        <p style="color:red">FALLO AL VERIFICAR CONTRASEÑA</p>
        <?php }?> 
		<form action="procesar_formulario.php" method="post" class="form-horizontal" >
       
 
					<div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Nombre</label>
					    <div class="col-sm-4">
					      <input class="form-control" type="text" name="nombre" id="formGroup" placeholder="Tu nombre">
					    </div>
					  </div>
 
					  <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Apellidos</label>
					    <div class="col-sm-4">
					      <input class="form-control" type="text" name="apellido" id="formGroup">
					    </div>
					  </div>
 
 
					  <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup" id="tel">Correo electrónico</label>
					    <div class="input-group col-sm-3">
					      <span class="input-group-addon">@</span>
					      <input class="form-control" type="email" name="correo" id="formGroup">
					      
					    </div>
					  </div>
 
					  <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">En que trabajas(redacta)</label>
					    <div class="col-sm-4">
					      
					      <textarea class="form-control" type="text" name="trabajo"></textarea>
					      
					    </div>
					  </div>
				
                      <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Cuantas mascotas tuviste ?</label>
					    <div class="col-sm-4">
					      
					      <input class="form-control" type="text" name="mascotas">
					      
					    </div>
                      </div>
                      
                      <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Por qué quieres una mascota rescatada ?</label>
					    <div class="col-sm-4">
					      
					      <input class="form-control" type="text" name="porque">
					      
					    </div>
                      </div>
                      <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Edad</label>
					    <div class="col-sm-4">
					      
					      <input class="form-control" type="number" name="edad">
					      
					    </div>
                      </div>
                      <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Distrito</label>
					    <div class="col-sm-4">
					      
					      <input class="form-control" type="text" name="distrito">
					      
					    </div>
                      </div>
                      <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Departamento</label>
					    <div class="col-sm-4">
					      
					      <input class="form-control" type="text" name="departamento">
					      
					    </div>
                      </div>
                      <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Cuentanos tus conocimientos</label>
					    <div class="col-sm-4">
					      
					      <textarea class="form-control" type="text" name="conocimientos"></textarea>
					      
					    </div>
					  </div>
 

						<br />
 
						<div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup"></label>
					    <div class="col-sm-4">
					      
							<button type="submit" class="btn btn-success btn-lg"><span class="glyphicon glyphicon-floppy-saved"></span> Guardar</button>
 
 
					    </div>
					  </div>
 
 
 
        </form>	
          
 
 
 
	</div>	
	
	
 
 
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.js"></script>    
</body>
</html>