<?php
    session_start();    
    if(!isset($_SESSION["correo"])){
        die("");

    } 
?>
<?php
$id=$_GET["id"];
$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8", "root", "");
$resultado= $pdo->query("SELECT * FROM mascota WHERE id = '$id'");
$mascota= $resultado->fetch();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <environment include="Development">
        <link rel="stylesheet" href="~/lib/bootstrap/dist/css/bootstrap.css" />
    </environment>
    <environment exclude="Development">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
              asp-fallback-href="~/lib/bootstrap/dist/css/bootstrap.min.css"
              asp-fallback-test-class="sr-only" asp-fallback-test-property="position" asp-fallback-test-value="absolute"
              crossorigin="anonymous"
              integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"/>    
    </environment>
    <title>Document</title>
</head>
<body>
<?php include 'menu.php' ?>
        <div class="container">
        <div class="row">
        <div class="col-8">
        <img style="width:700px" src="data:image/jpg;base64,<?php echo base64_encode($mascota['foto']);?>" alt="">
        </div>
        <div class="col-4" style="font-size:30px">
        <div>Nombre: <?php echo $mascota["nombre"]?></div>
        <hr>
        <div>Descripcion: <?php echo $mascota["descripcion"]?></div>
        <hr>
        <div>Numero del dueño: <?php echo $mascota["numero"]?></div>
        <div ><a href="editar.php?id=<?php echo $mascota["id"]?>">Editar</a></div>
        <div><a href="procesar_adoptar.php?id=<?php echo $mascota["id"]?>">Adoptar</a></div>
        <div><a href="borrar.php?id=<?php echo $mascota["id"]?>">Borrar</a></div>
        </div>
        </div>
        </div>
        
        <div class="container">
               <br>
               <a href="#ventana1" class="btn btn-primary btn-lg" data-toggle="modal">Inscribirme en la lista de espera</a>
               <div class="modal fade" id="ventana1">
               <div class="modal-dialog">
                   <div class="modal-content">
                   <div class="modal-header">
                       <button tyle="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                       <p class="modal-title">Quisieras adoptar a esta mascota ?</p>
                   </div>
                   <div class="modal-body">
                       <p>Tendras que pasar por cierta pruebas ok ?</p>
                       <p>Primero te enviaremos un mensaje aprobando tu informacion</p>
                       <p>Segundo nos comunicaremos contigo para hacer una videollamada</p>
                       <p>Tercer y ultimo paso deberas depositar una donacion de 30 s/. soles</p>
                       <p>Y tendras tu mascota esterilizada y saludable para ti</p>
                   </div>
                   <div class="modal-footer">
                           <p>Quieres iniciar con el proceso de adopcion ?</p>
                           <button type="button" class="btn btn-primary" data-dismiss="modal">si</button>
                           <button type="button" class="btn btn-primary" data-dismiss="modal">no</button>

                   </div>
                </div>
               </div>
            </div>

           </div>
    <environment include="Development">
    <script src="~/lib/jquery/dist/jquery.js"></script>
    <script src="~/lib/bootstrap/dist/js/bootstrap.bundle.js"></script>
    </environment>
    <environment exclude="Development">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"
     asp-fallback-src="~/lib/jquery/dist/jquery.min.js"
    asp-fallback-test="window.jQuery"
    crossorigin="anonymous"
    integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"
    asp-fallback-src="~/lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    asp-fallback-test="window.jQuery && window.jQuery.fn && window.jQuery.fn.modal"
    crossorigin="anonymous"
    integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o">
        </script>
    </environment>
    <script src="~/js/site.js" asp-append-version="true"></script>
</body>
</html>

