
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    
    <title> </title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="css/bootstrap.css" rel="stylesheet" />
	<link href="css/coming-sssoon.css" rel="stylesheet" />    
  <link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
  
</head>

<body>
    <?php
    $cuenta="visitas3.txt";
    function contador($cuenta){
      $fp=fopen($cuenta, 'r');
      $num=fgets($fp, 5);
      $num+=1;
      print "numero de visitas:";
      echo $num;
      exec("rm-rf $cuenta");
      exec("echo $num >$cuenta");
    }
    if(!file_exists($cuenta)){
      exec("echo 1>$cuenta");
    }
    contador($cuenta); 
    ?>   
<nav class="navbar navbar-transparent navbar-fixed-top" role="navigation">  
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <form action="procesar_idioma.php" method="get">
<select name="idiomaele" id="">
    <option value="Español">Español</option>
    <option value="Portuguez">Portuguez</option>
    <option value="Castelano">Castellano</option>
    <option value="Italiano">Italiano</option>
</select>
<select name="paiselegido" id="" method="get">
    <option value="PERU">Peru</option>
    <option value="CHILE">Chile</option>
    <option value="ARGENTINA">Argentina</option>
    <option value="BRAZIL">Brazil</option>
</select>
<button> Elegir </button>
</form>
      <ul class="nav navbar-nav navbar-right">
            <li>
                <a href="#"> 
                    <i class="fa fa-facebook-square"></i>
                    Share
                </a>
            </li>
             <li>
                <a href="#"> 
                    <i class="fa fa-twitter"></i>
                    Tweet
                </a>
            </li>
             <li>
                <a href="#"> 
                    <i class="fa fa-envelope-o"></i>
                    Email
                </a>
            </li>
       </ul>
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container -->
</nav>
<div class="main" style="background-image: url('images/default.jpg')">

<!--    Change the image source '/images/default.jpg' with your favourite image.     -->
    
    <div class="cover black" data-color="black"></div>
     
<!--   You can change the black color for the filter with those colors: blue, green, red, orange       -->

    <div class="container">
        <h1 class="logo cursive">
            RESCATE ANIMAL
        </h1>
        <div class="content">
            <h4 style="margin:0 0 0 400px; color:grey">Hagamos feliz a las mascotas de la calle</h4>
            <div class="container" style="margin: 30px 0 0 0">
           <div class="row">
           <div class="col-md-4"> 
             
          </div>
           <div class="col-md-4"> 
              <a href="esterilizar.php">
            <button style="width: 370px; color:beige" type="button" class="btn btn-default">COMENZAR</button>
          </a> 
          </div>
           <div class="col-md-4"> 
              
          </div>
          </div>
          </div>
            <div class="subscribe">
                <h5 class="info-text">
                    Escribe tu correo personal para recibir noticias de nuevas mascotas registradas 
                </h5>
                <div class="row">
                    <div class="col-md-4 col-md-offset-4 col-sm6-6 col-sm-offset-3 ">
                        <form class="form-inline" role="form">
                          <div class="form-group">
                            <label class="sr-only" for="exampleInputEmail2">Email address</label>
                            <input type="email" class="form-control transparent" placeholder="Your email here...">
                          </div>
                          <button type="submit" class="btn btn-danger btn-fill">Notify Me</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
      <div class="container">
             Made with <i class="fa fa-heart heart"></i> by <a href="index.php">Rescate Animal</a>. Free download 
      </div>
    
    </div>
 </div>
 </body>
   <script src="js/jquery-1.10.2.js" type="text/javascript"></script>
   <script src="js/bootstrap.min.js" type="text/javascript"></script>

</html>