<?php
$id=$_POST["id"];
$respuesta=$_POST["respuesta"];
$foto=addslashes(file_get_contents($_FILES['foto']['tmp_name']));
session_start();
$nombre=$_SESSION["nombre"];
$correo=$_SESSION["correo"];
$apellido=$_SESSION["apellido"];
$foto1=$_SESSION["foto"];
$numero=$_SESSION["numero"];
$unio=$_SESSION["fecha"];


$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8","root","");
$q= ("INSERT INTO respuesta VALUES (NULL,'$respuesta','$id',SYSDATE(),'$foto','$nombre','$correo','$apellido','$foto1','$numero','$unio')");
$pdo->query($q);


header("location:respuestas.php?id=$id");
?>