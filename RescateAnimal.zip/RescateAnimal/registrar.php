<?php
    session_start();    
    if(!isset($_SESSION["correo"])){
        die("");

    } 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/styles.css" />
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lobster" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.2/css/bootstrap.min.css" integrity="sha384-y3tfxAZXuh4HwSYylfB+J125MxIs6mR5FOHamPBG064zB+AFeWH94NdvaCBm8qnd" crossorigin="anonymous">
    <meta name="keywords" content="php, multilingüe, multiidioma,website">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.2/js/bootstrap.min.js" integrity="sha384-vZ2WRJMwsjRMW/8U7i6PWi6AlO1L79snBrmgiDpgIWJ82z8eA5lenwvxbMV1PAh7" crossorigin="anonymous"></script>
    <link href="css/bootstrap.css" rel="stylesheet" />
  	<link href="css/coming-sssoon.css" rel="stylesheet" />    
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
    <title>Document</title>
</head>
<body>
<?php include 'menu.php' ?>

<h3>Registrar nueva mascota</h3>
<form action="procesar_registrar.php" method="post" enctype="multipart/form-data">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Nombre de la mascota</label>
      <input type="text" name="t" class="form-control" id="inputEmail4" placeholder="Nombre">
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress">Descripcion</label>
    <textarea type="text" name="d" class="form-control" id="inputAddress" placeholder="Escribe la campaña al que deseas asistir" cols="30" rows="10"></textarea>
  </div>
  <div class="form-group">
    <label for="inputAddress2">Telefono</label>
    <input type="int" name="a" class="form-control" id="inputAddress2" placeholder="celular, ejemplo 990353375">
  </div>
  <div class="form-group">
    <label for="inputAddress">Sube la imagen</label>
    <input type="file" name="f" alt="40" class="form-control" id="inputAddress" placeholder="Escribe la campaña al que deseas asistir">
</div>
  <button type="submit" class="btn btn-primary">Nueva Mascota</button>
</form>

</body>
</html>