<?php
$holamundo="Inscribe a tu animal";
$hola="Si puedes inscribirte todas las personas que tengáis perro, gato, conejo y / o hurón en cualquier población de Lima-Peru";
$ho="El perro, el gato y / o el hurón deben estar identificados con el microchip –según prevé la Ley de Protección de los Animales–, y en el caso de que no hay, el requisito indispensable para colocarlos en el microchip antes de esterilizarlo";
$hol="¿Cómo puedo inscribir mi animal?";
$hoo="1.-Rellena el formulario de inscripción (uno para cada animal).";
$holl="2.-Anota el código de inscripción que recibirás automáticamente una vez hayas rellenado y enviado el formulario.";
$h= "En caso de pérdida puedes comprarlo contigo DNI
Pide presupuesto total a diferentes centros veterinarios y hora al interesado. No olvides que deberás facilitar el código de inscripción de cada animal.
Aquí tenemos los precios máximos establecidos por FAADA dentro de la campaña, escríbenos a través de la forma de contacto.
Para más información, contacta con FAADA.
Plazos para inscribir a tu animal
Puedes inscribir tu animal a partir del 5 de febrero de 2019. Recuerda la mayoría de los veterinarios finalizarán la campaña el 3 de mayo de 2019, pero algunos continuarán durante el año.";
$cambiarIdioma="Cambiar Idioma";
$soy="Soy";
$responsable="Responsable";
$r="Registrar a mi mascota";
$inicio="Casa";
$adoptar="Adoptar";
$esterizar="Esterizar";
$mascota="Foro Rescate";
$perfil="Perfil";
$visita="Vistas";
$cambiar="Cambiar";

$spanish="Español";
$english="Inglés";
$french="Francés";
$paul="Inscribe un tu animal Si puedes inscribirte todas las personas que tengáis perro, gato, conejo y / o hurón en cualquier población de Cataluña.
El perro, el gato y / o el hurón deben estar identificados con el microchip –según prevé la Ley de Protección de los Animales–, y en el caso de que no hay, el requisito indispensable para colocarlos en el microchip antes de esterilizarlo.
¿Cómo puedo inscribir mi animal?
Rellena el formulario de inscripción (uno para cada animal)
Anota el código de inscripción que recibirás automáticamente una vez hayas rellenado y enviado el formulario. En caso de pérdida puedes comprarlo contigo DNI
Pide presupuesto total a diferentes centros veterinarios y hora al interesado. No olvides que deberás facilitar el código de inscripción de cada animal.
Aquí tenemos los precios máximos establecidos por FAADA dentro de la campaña, escríbenos a través de la forma de contacto.
Para más información, contacta con FAADA.
Plazos para inscribir a tu animal
Puedes inscribir tu animal a partir del 5 de febrero de 2019. Recuerda la mayoría de los veterinarios finalizarán la campaña el 3 de mayo de 2019, pero algunos continuarán durante el año.";
$cerrar="Cerrar Sesion";
$registrar="Registrarse";
$iniciarsesion="Iniciar Sesion";
$abc="Esteriliza a tu Mascota en alguna campaña";
$nombre="Nombre";
$correo="Correo"; 
$campaña="Campaña";
$telefono="Telefono";
$razadelamascota="Raza de la mascota";
$Cuantosanimalestraeras="Cuántos animales traerás?";
$tuedad="Tu edad";
$departamento="Departamento";
$distrito="Distrito";
$Mecomprometoaasistir="Me comprometo asistir";
$Enviarformulario="Enviar formulario";
$titulo="Nuestras Campañas para el mes de Noviembre";
$a="Camapaña Cuida a tus amiguitos";
$b="Camapaña Dia de los animales";
$c="Ellos merecen lo mejor";
$d="";
