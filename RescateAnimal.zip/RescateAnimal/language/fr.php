<?php

$holamundo="Entrez votre animal";
$hola="Si vous pouvez enregistrer toutes les personnes que vous avez avec un chien, un chat, un lapin et / ou un furet dans n'importe quelle population de Catalogne.";
$ho="Le chien, le chat et / ou le furet doivent être identifiés avec la micropuce - conformément à la loi sur la protection des animaux - et, dans le cas contraire, l'exigence indispensable de les placer dans la micropuce avant de le stériliser.";
$hol="Comment puis-je enregistrer mon animal?";
$hoo="Remplissez le formulaire d'inscription (un pour chaque animal)";
$holl="Notez le code d'enregistrement que vous recevrez automatiquement une fois que vous aurez rempli et envoyé le formulaire.";
$h="En cas de perte, vous pouvez l'acheter avec votre carte d'identité.
Demandez un budget total aux différents centres vétérinaires et du temps à la partie intéressée. N'oubliez pas que vous devez fournir le code d'enregistrement de chaque animal.
Nous avons ici les prix maximum établis par FAADA dans le cadre de la campagne, écrivez-nous via le formulaire de contact.
Pour plus d'informations, contactez FAADA.
Dates limites pour enregistrer votre animal
Vous pouvez enregistrer votre animal à partir du 5 février 2019. N'oubliez pas que la plupart des vétérinaires termineront la campagne le 3 mai 2019, mais certains continueront tout au long de l'année.";
$cambiarIdioma="Changer de langue";
$soy="Je suis";
$responsable="Responsable";
$r="inscrire mon animal de compagnie";
$inicio="Maison";
$adoptar="Adotta";
$esterizar="Cucciolo";
$mascota="Forum di salvataggio";
$perfil="Profilo";
$visita="Visualizzazioni";
$cambiar="Cambia";

$spanish="Espanol";
$english="Anglais";
$french="Français";
$paul="Entrez votre animal
Si vous pouvez enregistrer toutes les personnes que vous avez avec un chien, un chat, un lapin et / ou un furet dans n'importe quelle population de Catalogne.
Le chien, le chat et / ou le furet doivent être identifiés avec la micropuce - conformément à la loi sur la protection des animaux - et, dans le cas contraire, l'exigence indispensable de les placer dans la micropuce avant de le stériliser.
Comment puis-je enregistrer mon animal?
Remplissez le formulaire d'inscription (un pour chaque animal)
Notez le code d'enregistrement que vous recevrez automatiquement une fois que vous aurez rempli et envoyé le formulaire. En cas de perte, vous pouvez l'acheter avec votre carte d'identité.
Demandez un budget total aux différents centres vétérinaires et du temps à la partie intéressée. N'oubliez pas que vous devez fournir le code d'enregistrement de chaque animal.
Nous avons ici les prix maximum établis par FAADA dans le cadre de la campagne, écrivez-nous via le formulaire de contact.
Pour plus d'informations, contactez FAADA.
Dates limites pour enregistrer votre animal
Vous pouvez enregistrer votre animal à partir du 5 février 2019. N'oubliez pas que la plupart des vétérinaires termineront la campagne le 3 mai 2019, mais certains continueront tout au long de l'année.";
$cerrar="Connectez Out";
$registrar="Enregister";
$iniciarsesion="Commencer la session";

$abc="Stérilisez votre animal dans n'importe quelle campagne";

$nombre="Nom";
$correo="Email"; 
$campaña="Cloche";
$telefono="Téléphone";
$razadelamascota="course d'animaux";
$Cuantosanimalestraeras="Combien d'animaux allez-vous apporter?";
$tuedad="ton âge";
$departamento="Département";
$distrito="District";
$Mecomprometoaasistir="Je promets d'y assister";
$Enviarformulario="Envoyer le formulaire";

$titulo="Nos campagnes pour le mois de novembre";
$a="Camapaña Prenez soin de vos amis";
$b="Camapaña Jour des animaux";
$c="Ils méritent le meilleur
";
$d="";