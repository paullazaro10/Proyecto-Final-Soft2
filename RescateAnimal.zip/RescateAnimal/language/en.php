<?php
$holamundo="Enter your animal";
$hola="If you can register all the people that you have dog, cat, rabbit and / or ferret in any population of Catalonia.";
$ho="dog, the cat and / or the ferret must be identified with the microchip -according to the Law on the Protection of Animals-, and in the case that there is not, the indispensable requirement to place them in the microchip before sterilizing it.";
$hol="How can I register my animal?";
$hoo="1.-Fill out the registration form (one for each animal)";
$holl="2.-Write down the registration code that you will automatically receive once you have filled out and sent the form.";
$h="In case of loss you can buy it with you ID
Ask for a total budget to different veterinary centers and time to the interested party. Do not forget that you must provide the registration code of each animal.
Here we have the maximum prices established by FAADA within the campaign, write us through the contact form.
For more information, contact FAADA.
Deadlines to register your animal
You can register your animal as of February 5, 2019. Remember most veterinarians will complete the campaign on May 3, 2019, but some will continue throughout the year.";
$cambiarIdioma="Change Language";
$soy="I am";
$responsable="Responsible";
$r="Register my pet";
$inicio="Home";
$adoptar="Adopt";
$esterizar="Ester";
$mascota="Rescue Forum";
$perfil="Profile";
$visita="Views";
$cambiar="Change";

$spanish="Spanish";
$english="English";
$french="French";
$paul="Enter your animal If you can register all the people that you have dog, cat, rabbit and / or ferret in any population of Catalonia.
The dog, the cat and / or the ferret must be identified with the microchip -according to the Law on the Protection of Animals-, and in the case that there is not, the indispensable requirement to place them in the microchip before sterilizing it.
How can I register my animal?
Fill out the registration form (one for each animal)
Write down the registration code that you will automatically receive once you have filled out and sent the form. In case of loss you can buy it with you ID
Ask for a total budget to different veterinary centers and time to the interested party. Do not forget that you must provide the registration code of each animal.
Here we have the maximum prices established by FAADA within the campaign, write us through the contact form.
For more information, contact FAADA.
Deadlines to register your animal
You can register your animal as of February 5, 2019. Remember most veterinarians will complete the campaign on May 3, 2019, but some will continue throughout the year.";
$cerrar="Logout";
$registrar="Register";
$iniciarsesion="Login";
$abc="Sterilize your pet in any campaign";
$nombre="Name";
$correo="Email"; 
$campaña="Bell";
$telefono="Telephone";
$razadelamascota="Pet race";
$Cuantosanimalestraeras="How many animals will you bring?";
$tuedad="your age";
$departamento="Departament";
$distrito="District";
$Mecomprometoaasistir="I promise to attend";
$Enviarformulario="Send Form";
$titulo="
Our Campaigns for the month of November";
$a="
Camapaña Take care of your friends";
$b="Camapaña Day of the animals";
$c="Ils méritent le meilleur";
$d="";