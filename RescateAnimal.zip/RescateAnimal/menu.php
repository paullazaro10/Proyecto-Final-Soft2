<?php
if (isset($_COOKIE["pais"])) {
    $paais = $_COOKIE["pais"];
}
else{
    header("location: seleccionar.php");
    exit;
}    
if (isset($_COOKIE["idioma"])) {
    $idiioma = $_COOKIE["idioma"];

}
else{
    header("location: seleccionar.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        
        <title>menu</title>
        <!-- Our CSS stylesheet file -->
        <link rel="stylesheet" href="assets/css/styles.css" />
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lobster" />
    </head>
    <body>   
        <nav>
            <ul class="fancyNav">
                
                <?php if(isset($_SESSION["correo"])) { ?>
                    
                    <li id="home"><a href="index.php" >Home</a></li>
                    <li><a href="index.php">Cambiar</a></li>
                    <li id="news"><a href="lista.php">Adoptar</a></li>
                    <li id="visitas"><a href="visitas.php">Visitas</a></li>
                    <li id="services"><a href="foro.php">Mascotas Perdidas</a></li>
                <li id="about"><a href="esterilizar.php">Esterizar</a></li>
                <li id="visitas"><a href="Logout.php">Cerrar Sesion</a></li>

                <?php } else{?>
                    <li id="visitas"><a href="registrar_usuario.php">Registrarse</a></li>
                    <li id="visitas"><a href="login.php">Iniciar sesion</a></li>
                <?php } ?>
                <h3 style="margin:0 0 0 830px;font-size:15px"> <?php echo $idiioma; ?> </h3>
                <h3 style="margin:0 0 0 830px;font-size:15px"> <?php echo $paais; ?>   </h3>

            </ul>
        </nav>
            
    </body>
</html>
