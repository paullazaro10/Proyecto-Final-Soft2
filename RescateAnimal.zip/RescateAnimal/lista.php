<?php
    session_start();    
    if(!isset($_SESSION["correo"])){
        die("");

    } 
?>
<?php
$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8", "root", "");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

  <!-- Custom styles for this page -->
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
  <title></title>
    <style>
      
      .padre{ 
        width:100%;
        height: 420px;
        margin: 0 auto;
        display:flex;
        flex-direction:row;
        flex-wrap: wrap;
        justify-content:center;
        padding:0px;
        
    }
    .hijo{
        background-color:white;
        font-size: 12px;
        color: lightskyblue;
        text-align: center;
        margin:20px 0px 20px 20px;
        width:18.6%;
        height:340px; 
        padding: 0px;
        position: relative;
        display: inline-block;
        text-align: center;
    }
      .imagen:hover {-webkit-transform:scale(1.3);transform:scale(1.3);}
    .imagen {overflow:hidden;
       -webkit-filter: saturate(2);  filter:saturate(1.6);
       border-radius: 10%;
       box-shadow: 0 5px 80px rgba(0, 0, 0, 0.2);
    }
    </style>
</head>
<body>
<?php
$cuenta="visitas4.txt";
function contador($cuenta){
  $fp=fopen($cuenta, 'r');
  $num=fgets($fp, 5);
  $num+=1;
  print "numero de visitas: ";
  echo $num;
  exec("rm-rf $cuenta");
  exec("echo $num >$cuenta");
}
if(!file_exists($cuenta)){
  exec("echo 1>$cuenta");
}
contador($cuenta); 
?>  
<?php include 'menu.php' ?>
<h4><a href="registrar.php">Registra mascotas</a></h4>
            <h3>NUEVAS MASCOTAS</h3>

           <div class="padre" >
           <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>'35'  ") as $fila) { ?>
            <div class="hijo" style="border-radius:10%">  
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            <a href=""><button class="btn btn-primary; centrado">CONÓCEME</button></a>
            </div>     
            <?php } ?>
           </div>

           




<!--ss-->
<div class="container-fluid">
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr >
            
            <th >Mascotas disponibles </th>
            <th>para ser adoptadas</th>
            <th></th> 
          </tr>
          
        </thead>
        <tfoot>
          <tr>
            <th>No son las unica</th>
            <th>mascotas que tenemos</th>
            <th></th>
            
          </tr>
        </tfoot>
        <tbody>
          
          <tr>
          <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id<='3'  ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            </td>
            <?php } ?>
          </tr>
          <tr> 
            <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>='4' and id<='6' ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            
            </td>
            <?php } ?>
          </tr> 
          <tr> 
            <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>='7' and id<='9' ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            
            </td>
            <?php } ?>
          </tr> 
          <tr> 
            <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>='10' and id<='12' ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            
            </td>
            <?php } ?>
          </tr> 
          <tr> 
            <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>='13' and id<='15' ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            
            </td>
            <?php } ?>
          </tr> 
          <tr> 
            <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>='16' and id<='18' ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            
            </td>
            <?php } ?>
          </tr>
          <tr> 
            <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>='19' and id<='21' ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            
            </td>
            <?php } ?>
          </tr>

          <tr> 
            <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>='22' and id<='24' ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            
            </td>
            <?php } ?>
          </tr> 
          <tr> 
            <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>='25' and id<='27' ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
           
            </td>
            <?php } ?>
          </tr> 
          <tr> 
            <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>='28' and id<='30' ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            
            </td>
            <?php } ?>
          </tr>
          <tr> 
            <?php foreach ($pdo->query("SELECT * FROM mascota WHERE id>='31' and id<='33'  ") as $fila) { ?>
            <td>
            <div style="color:black;font-size:1px"><?php echo $fila["descripcion"] ?></div>
            <a href="informacion.php?id=<?php echo $fila["id"]?>"><img class="imagen" style="width:350px;height:250px" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>"></a>
            
            </td>
            <?php } ?>
          </tr>
          
        </tbody>
      </table>
      
    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->

</div>

<div class="container">
  <div class="row">
    <div class="col-5">
   <h3>COMENTAR </h3>
   <form action="registrar_comentarios.php" method="post">
     <div>
        nombre: 
        <input type="text" name="n" id="">
     </div>
     <div>
     correo:
        <input type="email" name="c" id="">
    </div>
    <div>
        comentar:
        <textarea name="m" id="" cols="30" rows="10"></textarea>
    </div>
    <button > Registrar comentario </button>
    </form>
    </div>

<div class="col-7">
<?php foreach ($pdo->query("SELECT * FROM comentarios ") as $fila) { ?>
<div><?php echo $fila["nombre"] ?></div>
<div><?php echo $fila["comentarios"] ?></div>
<div><?php echo $fila["fecha"] ?></div>
<?php } ?>
</div>
</div>
</div>











  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>
</html>