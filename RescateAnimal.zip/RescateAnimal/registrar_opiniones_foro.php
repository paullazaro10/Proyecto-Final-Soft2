<?php
$id=$_POST["id"];
$opinion = $_POST["c"];
$titulo=$_POST["t"];
session_start();
$nombre=$_SESSION["nombre"];
$correo=$_SESSION["correo"];
$apellido=$_SESSION["apellido"];
$foto=$_SESSION["foto"];
$numero=$_SESSION["numero"];
$unio=$_SESSION["fecha"];


$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8","root","");
$q= ("INSERT INTO opinion VALUES (NULL,'$opinion','$id','$titulo','$nombre','$correo','$apellido','$foto','$numero',SYSDATE(),'$unio')");
$pdo->query($q);


header("location:opiniones.php?id=$id");
?>