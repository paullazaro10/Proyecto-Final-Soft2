<?php    
    session_start();    
    if(isset($_SESSION["correo"])){
    die();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registrar Usuario</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style1.css">
</head>
<body style="background-image: url(images/huellas.jpg);">

    <div class="container well" style="margin:0 0 0 300px;color:black">
		<div class="row">
				<div class="col-xs-12"><h3>Crea tu perfil <img style="width:60px" src="images/imag.jpg" alt=""></h3></div>
			</div>
		<br /><br />
        <h1>Registrar Usuario Nuevo <img style="width:60px" src="images/imag.jpg" alt=""></h1>
        <?php if(isset($_GET["error"])) {?>
        <p style="color:red">FALLO AL VERIFICAR CONTRASEÑA</p>
        <?php }?> 
		<form action="procesar_usuario.php" method="post" class="form-horizontal">
       
 
					<div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Nombre</label>
					    <div class="col-sm-4">
					      <input class="form-control" type="text" name="nombres" id="formGroup" placeholder="Tu nombre">
					    </div>
					  </div>
 
					  <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Apellidos</label>
					    <div class="col-sm-4">
					      <input class="form-control" type="text" name="apellidos" id="formGroup">
					    </div>
					  </div>
 
 
					  <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup" id="tel">Correo electrónico</label>
					    <div class="input-group col-sm-3">
					      <span class="input-group-addon">@</span>
					      <input class="form-control" type="text" name="correo" id="formGroup">
					      
					    </div>
					  </div>
 
					  <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Contraseña</label>
					    <div class="col-sm-4">
					      
					      <input class="form-control" type="password" name="contra">
					      
					    </div>
					  </div>
				
                      <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Confirmar contraseña </label>
					    <div class="col-sm-4">
					      
					      <input class="form-control" type="password" name="confirmar">
					      
					    </div>
                      </div>
                      
                      <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Fecha de nacimiento</label>
					    <div class="col-sm-4">
					      
					      <input class="form-control" type="date" name="fechanac">
					      
					    </div>
					  </div>
					  <div class="form-group">
                     <label for="inputAddress">Sube la imagen</label>
                      <input type="file" name="foto" alt="40" class="form-control"placeholder="archiva tu fotografia" >
                      </div>
					  </div>
					  <div class="form-group">
                     <label for="inputAddress">NUMERO PERSONAL</label>
                      <input   type="number" name="numero" alt="40" class="form-control"  placeholder="numero de celu">
                      </div>
					
 

						<br />
 
						<div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup"></label>
					    <div class="col-sm-4">
					      
							<button type="submit" class="btn btn-success btn-lg"><span class="glyphicon glyphicon-floppy-saved"></span> Guardar</button>
 
 
					    </div>
					  </div>
 
 
 
		</form>	
 
 
 
	</div>	
	
	
 
 
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.js"></script>    
</body>
</html>