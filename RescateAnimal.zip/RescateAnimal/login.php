<?php 
    session_start();
    if(isset($_SESSION["correo"])){
        die("");

    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LOGIN</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style1.css">
    <link rel="stylesheet" href="style1.css">
    <style>
    </style>
</head>
<body style="background-image:url(images/fo.jpg)">
<?php include 'menu.php' ?>
  <div class="container" style="background-image:url(images/fon.jpg);width:700px">
    <div class="row">
    <div class="col-12">
    <h3>INICIAR SESION</h3>
    <hr>
    <br>
    <?php if(isset($_GET["error"])) {?>
        <p style="color:red;">Error intente nuevamente</p>
    <?php }?>
    <form action="procesar_login.php" method="post" class="form-horizontal" >
					  <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup" id="tel">Correo electrónico</label>
					    <div class="input-group col-sm-3">
					      <span class="input-group-addon">@</span>
					      <input class="form-control" type="email" name="correo" id="formGroup">  
					    </div>
					  </div>
 
					  <div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup">Contraseña</label>
					    <div class="col-sm-4">
					      <input class="form-control" type="password" name="contraseña">					      
					    </div>
					  </div>
						<br />
						<div class="form-group">
					    <label class="col-sm-2 control-label" for="formGroup"></label>
					    <div class="col-sm-4">
							<button type="submit" class="btn btn-success btn-lg"><span class="glyphicon glyphicon-floppy-saved"></span> INICIAR SESION</button>
					    </div>
					  </div>
 
 
 
		</form>	
        </div></div>
        </div>
</body>
</html>