
<?php
$id=$_GET['id'];
$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8","root","");
$q = ("INSERT INTO carrito(foto) SELECT(foto)FROM mascota WHERE id='$id'");
$pdo->query($q);




header("location:formulario.php");  

?>
 
