<?php
$n = $_POST["nombre"];
$a = $_POST["apellido"];
$c = $_POST["correo"];
$e= $_POST["edad"];
$t = $_POST["trabajo"];
$m = $_POST["mascotas"];
$p = $_POST["porque"];
$d = $_POST["departamento"];
$di = $_POST["distrito"];
$co = $_POST["conocimientos"];


$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8","root","");
$q= ("INSERT INTO postulantes VALUES (NULL, '$n','$a','$c','$e','$t','$m','$p','$d','$di','$co')");
$pdo->query($q);


header("location:confirmacion_formulario.php");
?>