<?php
$nombre = $_POST["nombre"];
$correo = $_POST["correo"];
$campaña = $_POST["campaña"];
$telefono = $_POST["telefono"];
$raza = $_POST["raza"];
$animales = $_POST["animales"];
$edad = $_POST["edad"];
$departamento = $_POST["departamento"];
$distrito = $_POST["distrito"];

$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8","root","");
$q= ("INSERT INTO esterilizar VALUES (NULL, '$nombre','$correo','$campaña','$telefono','$raza','$animales','$edad','$departamento','$distrito')");
$pdo->query($q);


header("location:esterilizar_confirmacion.php");
?>