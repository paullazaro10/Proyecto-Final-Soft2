<?php
    #entrada
    $nombres=$_POST["nombres"];
    $apellidos=$_POST["apellidos"];
    $correo=$_POST["correo"];
    $contra=$_POST["contra"];
    $confirmar=$_POST["confirmar"];
    $fechanac=$_POST["fechanac"];
    $numero=$_POST["numero"];
    $foto=$_POST["foto"];
    #proceso
    if($contra!=$confirmar){
        header("Location:registrar_usuario.php?error=1");
    }
    else{
        $contra=sha1($contra);
        $db= new PDO('mysql:host=localhost;dbname=mascotas;charset=utf8mb4','root','');
        $db->query("INSERT INTO usuario VALUES(NULL,'$correo','$contra',SYSDATE(),'$nombres','$apellidos','$fechanac','$foto','$numero')");
        #salida
        header("Location:esterilizar.php");
    }
    
    
?>