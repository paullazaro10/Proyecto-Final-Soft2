<?php
    session_start();    
    if(!isset($_SESSION["correo"])){
        die("");

    } 
?>
<?php
$id=$_GET["id"];
$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8", "root", "");
$resultado= $pdo->query("SELECT * FROM foro WHERE id = '$id'");
$mascota= $resultado->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<?php include 'menu.php' ?>

      
      <div class="container" style="color: green">
        <h3>RESPONDER AL FORO:<?php echo $mascota["tema"]?></h3>
          <div class="row">
            <div class="col-3">
                <p>Publicado por:<?php echo $mascota["nombre"]?> <?php echo $mascota["apellido"]?></p>
                <img width=150px src="images/<?php echo $mascota['foto'] ?>" alt=""> 
                <p><?php echo $mascota["correo"]?></p>
                <p><?php echo $mascota["numero"]?></p> 
                <p>Se unio en:<?php echo $mascota["unio"]?></p>            
            </div>
            <div class="col-6">
            <a style="font-size: 20px" href="#"><?php echo $mascota["titulo"]?>:</a>
            <p style="font-size: 13px"><?php echo $mascota["tema"]?></p>
            <p><?php echo $mascota["fecha"]?></p>
            </div>
            <div class="col-2">
             <!--imgen-->            
            </div>
          </div>
      </div>
       <hr />

      
     <div class="container" style="color: lightseagreen">
         <div class="row">
            <div class="col-9">
            <?php foreach ($pdo->query("SELECT * FROM opinion WHERE tema='$id'") as $fila) { ?> 
                        
                        <div class="container" style="color: black;border: 1px solid lightgreen">
                            <div class="row">
                            <div class="col-4">   
                            <p style="font-size: 15px">Usuario:<?php echo $fila["nombre"]?> <?php echo $fila["apellido"]?></p>
                            <img width=60px src="images/<?php echo $fila["foto"]?>" alt="">
                            <p><?php echo $fila["numero"]?></p>
                            <p><?php echo $fila["correo"]?></p>
                            <p>Se unio el:<?php echo $fila["unio"]?></p>
                           </div> 
                           <div class="col-8">
                           <p><?php echo $fila["titulo"] ?></p>
                               <p><?php echo $fila["opiniones"] ?></p>
                               <p style="font-size: 15px">Publicado en: <div style="color:blue"><?php echo $fila["fecha"]?></div></p>
                            <a href="respuestas.php?id=<?php echo $fila["id"]?>">Respuestas</a>
                            </div>    
                        </div>
                       </div>
                       <?php } ?>
           </div> 
                   
    <div class="col-3">
    <form action="registrar_opiniones_foro.php" method="post">
       <input type="hidden" name="id" value="<?php echo $id?>">
     <div>
        Titulo del comentario:
        <textarea type="text" class="form-control rounded-0" name="t" ></textarea>
        Comentario:
        <textarea type="text" class="form-control rounded-0" name="c" ></textarea>

        
    </div>
    <button class="btn btn-success"> Nuevo comentario </button>
    </form>
    </div>
    </div>
    </div>

    
</body>
</html>