<?php
    session_start();    
    if(!isset($_SESSION["correo"])){
        die("");

    } 
?>
<?php
$id=$_GET["id"];
$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8", "root", "");
$resultado= $pdo->query("SELECT * FROM opinion WHERE id = '$id'");
$mascota= $resultado->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<?php include 'menu.php' ?>
<hr>
<br>
<h3 style="margin:0 0 0 40px">RE:</h3>
<div class="container" style="color: black;border: 4px solid gray">
    <div class="row">
        
     <div class="col-5" >  
       <p style="font-size: 15px">Usuario:<a style="color:gray;font-size:20px"><?php echo $mascota["nombre"]?> <?php echo $mascota["apellido"]?></p>
       <img style="width:120px; margin: 0 0 20px 70px" src="images/<?php echo $mascota["foto"]?>" alt="">
       <p>Numero cel: <?php echo $mascota["numero"]?></p>
       <p>Email: <?php echo $mascota["correo"]?></p>
        Se unio el: <?php echo $mascota["unio"]?>
       
     </div> 
     <div class="col-6">
        <h3>Titulo:<?php echo $mascota["titulo"]?></h3>
        <div style="font-size: 16px; color:white; background-color:gray">Comentario:<?php echo $mascota["opiniones"]?></div>
        <p style="font-size: 16px">Publicado el: <a style="color:gray"><?php echo $mascota["fecha"]?></p>

        <form action="registrar_respuesta.php" method="post" enctype="multipart/form-data">
       <input type="hidden" name="id" value="<?php echo $id?>">
       <div>
        <textarea type="text" class="form-control rounded-0" name="respuesta" id="" cols="24" rows="4"></textarea>
        </div>
        <div>
            <input class="btn btn-info" type="file" name="foto" id="">
        </div>  
        <hr> 
      <button class="btn btn-info" > respuesta </button>
      </form>
     </div>    
    </div>
</div>
<hr>
<h3 style="margin:0 0 0 100px">RESPUESTAS:</h3>
<hr>

    <?php foreach ($pdo->query("SELECT * FROM respuesta WHERE opinion='$id'") as $fila) { ?>
     <div class="container" style="color: black;border: 3px solid lightgreen">
     <div class="row">
       <div class="col-3">
       <h2>RE:RE:</h2>    
       <p style="font-size: 20px">Usuario:<div style="color:blue"><?php echo ($fila['nombre'])?><?php echo ($fila['apellido'])?></div></p>
       <img style="width:50px" src="images/<?php echo ($fila['foto1'])?>" alt="">
       <p>Numero cel: <?php echo $fila["numero"]?></p>
       <p>Email: <?php echo $fila["correo"]?></p>
        Se unio el: <?php echo $fila["unio"]?>
     </div> 
     <div class="col-5">
        <div style="font-size: 20px; color:white; background-color:gray"><?php echo $mascota["opiniones"]?></div>
        <div style="font-size: 25px"><?php echo $fila["respuesta"]?></div>
        <p style="font-size: 20px">Publicado el: <div style="color:blue"><?php echo ($fila['fecha']);?></div></p>
     </div>
     <div class="col-4">
     <img style="width:220px;" src="data:image/jpg;base64,<?php echo base64_encode($fila['foto']);?>">
     </div>   
    </div>
   </div>
   <?php } ?>
    
</body>
</html>