<?php
$idioma = $_GET["idiomaele"];
$pais = $_GET["paiselegido"];


setcookie("idioma","$idioma", time() + 60*60*24*7  );
setcookie("pais","$pais", time() + 60*60*24*7  );


header("location:esterilizar.php");


?>