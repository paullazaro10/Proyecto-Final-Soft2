<?php
$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8", "root", "");
?>
<?php
if (isset($_COOKIE["pais"])) {
    $paais = $_COOKIE["pais"];
}
else{
    header("location: .php");
    exit;
}    
if (isset($_COOKIE["idioma"])) {
    $idiioma = $_COOKIE["idioma"];

}
else{
    header("location: seleccionar.php");
    exit;
}
?>

<?php
session_start();
require 'requirelanguage.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/styles.css" />
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lobster" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.2/css/bootstrap.min.css" integrity="sha384-y3tfxAZXuh4HwSYylfB+J125MxIs6mR5FOHamPBG064zB+AFeWH94NdvaCBm8qnd" crossorigin="anonymous">
    <meta name="keywords" content="php, multilingüe, multiidioma,website">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.2/js/bootstrap.min.js" integrity="sha384-vZ2WRJMwsjRMW/8U7i6PWi6AlO1L79snBrmgiDpgIWJ82z8eA5lenwvxbMV1PAh7" crossorigin="anonymous"></script>
    <link href="css/bootstrap.css" rel="stylesheet" />
  	<link href="css/coming-sssoon.css" rel="stylesheet" />    
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
</head>
<style>
header {
  position: relative;
  height: 75vh;
  min-height: 25rem;
  width: 100%;
  overflow: hidden;
}

header video {
  position: absolute;
  top: 50%;
  left: 50%;
  min-width: 100%;
  min-height: 100%;
  width: auto;
  height: auto;
  z-index: 0;
  -ms-transform: translateX(-50%) translateY(-50%);
  -moz-transform: translateX(-50%) translateY(-50%);
  -webkit-transform: translateX(-50%) translateY(-50%);
  transform: translateX(-50%) translateY(-50%);
}

header .container {
  position: relative;
  z-index: 2;
}

header .overlay {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  background-color: black;
  opacity: 0.5;
  z-index: 1;
  
}
</style>
<div style="background-color:#c6b1c9">
<body style="font-family: 'Ciutadella Semibold', sans-serif;">
<?php
$cuenta="visitas1.txt";
function contador($cuenta){
  $fp=fopen($cuenta, 'r');
  $num=fgets($fp, 5);
  $num+=1;
  print " Views: ";
  echo $num;
  exec("rm-rf $cuenta");
  exec("echo $num >$cuenta");
}
if(!file_exists($cuenta)){
  exec("echo 1>$cuenta");
}
contador($cuenta); 
?>  



<nav>
            <ul class="fancyNav">
                <li id="home"><a href="index.php" ><?php echo $inicio ?></a></li>
                <?php if(isset($_SESSION["correo"])) { ?>
                    <li id="news"><a href="lista.php"><?php echo $adoptar ?></a></li>
                    <li id="visitas"><a href="visitas.php"><?php echo $visita ?></a></li>
                <li><a href="index.php"><?php echo $cambiar ?></a></li></a></li>
                    <li id="services"><a href="foro.php"><?php echo $mascota ?></a></li>
                <li id="about"><a href="esterilizar.php"><?php echo $esterizar ?></a></li>
                <li id="visitas"><a href="Logout.php"><?php echo $cerrar ?></a></li>

                <li><a href="index.php"><?php echo $cambiar ?></a></li>
                <?php } else{?>
                    <li id="visitas"><a href="registrar_usuario.php"><?php echo $registrar ?></a></li>
                    <li id="visitas"><a href="login.php"><?php echo $iniciarsesion ?></a></li>
                <?php } ?>
                <h3 style="margin:0 0 0 830px;font-size:15px"> <?php echo $idiioma; ?> </h3>
                <h3 style="margin:0 0 0 830px;font-size:15px"> <?php echo $paais; ?>   </h3>

            </ul>
        </nav>
<!--aqui empieza el manu-->

<!--aqui acaba el menu-->

<header>
  <div class="overlay"></div>
  <video playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop">
    <source src="dog.mp4" type="video/mp4">
  </video>
  <div class="container h-100">
    <div class="d-flex h-100 ">
      <div class="w-100">
    <!--aaqui empieza el boton--> 
    <br> 
  <div class="dropdown closed">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color:white;margin: 0 0 0 900px; color:black">
    <?php echo $cambiarIdioma; ?>
    
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenu2" style="margin: 0 0 0 900px">
      <a href="changelanguage.php?language=es">
    <button class="dropdown-item" type="button"><?php echo $spanish; ?></button>      
      </a>
      <a href="changelanguage.php?language=en">
    <button class="dropdown-item" type="button"><?php echo $english; ?></button>
      </a>
      <a href="changelanguage.php?language=fr">
    <button class="dropdown-item" type="button"><?php echo $french; ?></button>
      </a>
  </div>
</div>
<!--aqui acaba el boton de cambiar idioma-->
      <p  style="margin:30px 0 0 60px;font-size:70px;color:white"><?php echo $soy; ?></p>
      <p  style="margin: 0 0 0 60px;font-size:70px;color:white"><?php echo $responsable; ?></p>
      <a href="index.php">
            <button style="width: 450px; color:white;font-size:20px;margin:30px 0 0 60px" type="button" class="btn btn-default"><?php echo $r ?></button>
          </a> 

     
      </div>
    </div>
  </div>
</header>
<!--idioma-->
<div class="container">
  <div class="row">
    <div class="col-6" style="font-size:16px">
             <br>
             <hr>
             
            <div style="color:purple;font-size:23px"><?php echo $holamundo; ?></div>
            <hr>
            <div><?php echo $hola ?></div>
            <br>
            <div><?php echo $ho ?></div>
            <hr>
            <div style="color:purple;font-size:23px"><?php echo $hol ?></div>
            <br>
            <div><?php echo $hoo ?></div>
            <div><?php echo $holl ?></div>
            <h3><?php echo $titulo ?></h3>
               <hr>
               <h3> <?php echo $a ?> </h3>
               <img style="width:40px" src="images/campaña1.jpg" alt="">
               Direccion: Av.Pardos Miraflores
               <hr>
               <h3> <?php echo $b ?> </h3>
               <img style="width:40px" src="images/campaña2.jpg" alt="">
               Direccion: Av.Benavides 2234 Surco
               <hr>
               <h3> <?php echo $b ?> </h3>
               <img style="width:40px" src="images/campaña3.jpg" alt="">
               Direccion: Av.Benavides 12 Miraflores
               <hr>
               <h3><?php echo $c ?></h3>
               <img style="width:40px" src="images/campaña4.jpg" alt="">
               Direccion: Av.La Fontana 123 La Molina

    </div>
    <div class="col-6">
    <br>
    <hr>
    <h3><?php echo $abc ?></h3>
    <hr>
    <br>
    <form action="procesar_esterilizar.php" method="post">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4"><?php echo $nombre ?></label>
      <input type="text" name="nombre" class="form-control" id="inputEmail4" placeholder="Nombre">
    </div>
    <div class="form-group col-md-6">
      <label for="inputEmail4"><?php echo $correo ?></label>
      <input type="email" name="correo" class="form-control" id="inputEmail4" placeholder="Correo">
    </div> 
  </div>
  <div class="form-group">
    <label for="inputAddress"><?php echo $campaña ?></label>
    <input type="text" name="campaña" class="form-control" id="inputAddress" placeholder="Escribe la campaña al que deseas asistir">
  </div>
  <div class="form-group">
    <label for="inputAddress2"><?php echo $telefono ?></label>
    <input type="number" name="telefono" class="form-control" id="inputAddress2" placeholder="celular, ejemplo 990353375">
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity"><?php echo $razadelamascota ?></label>
      <input type="text" name="raza" class="form-control" id="escribe la raza, ejemplo,es de raza labrador">
    </div>
    <div class="form-group col-md-4">
      <label for="inputState"><?php echo $Cuantosanimalestraeras ?></label>
      <select id="inputState" name="animales" class="form-control">
        <option selected>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
      </select>
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip"><?php echo $tuedad ?></label>
      <input type="number" name="edad" class="form-control" id="Tu edad">
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress"><?php echo $departamento ?></label>
    <input type="text" name="departamento" class="form-control" id="inputAddress" placeholder="Escribe la campaña al que deseas asistir">
  </div>
  <div class="form-group">
    <label for="inputAddress2"><?php echo $distrito ?></label>
    <input type="text" name="distrito" class="form-control" id="inputAddress2" placeholder="celular, ejemplo 990353375">
  </div>
  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck" >
      <br>
        <div><?php echo $Mecomprometoaasistir ?></div>
      </label>
    </div>
  </div>
  <button type="submit" class="btn btn-primary"><?php echo $Enviarformulario ?></button>
</form>

    </div>
  </div>
</div>

<!--idioma-->

  
<img style="margin:0 0 0 60px;width:500px" src="esterilizar.jpg" alt="100px">

</div>
</body>
</html>