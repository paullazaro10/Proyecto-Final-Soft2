<?php
    session_start();    
    if(!isset($_SESSION["correo"])){
        die("");

    } 
?>
<?php
$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8", "root", "");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <title></title>
</head>
<body>
<?php
$cuenta="visitas2.txt";
function contador($cuenta){
  $fp=fopen($cuenta, 'r');
  $num=fgets($fp, 5);
  $num+=1;
  print "numero de visitas: ";
  echo $num;
  exec("rm-rf $cuenta");
  exec("echo $num >$cuenta");
}
  if(!file_exists($cuenta)){
  exec("echo 1>$cuenta");
  }
contador($cuenta); 
?>  
<?php include 'menu.php' ?>




<!-- para crear el  tema del foro-->
<div class="container">
  <div class="row">
   <div class="col-7">
<!--FORO-->
<div class="container-fluid">
<div class="card shadow mb-4">
  <div class="card-header py-3">
      <h3>ENCUENTRA MAS RAPIDO A TU MASCOTA!</h3>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Autor </th>
            <th>Nuevas Noticias en nuestro Foro</th>
            <th>Fecha de publicación</th>
            <th>Numero de celular</th>
                      
          </tr>
          
        </thead>
        <tfoot>
          <tr>
            <th>Autor</th>
            <th>Nuevas Noticias en nuestro Foro</th>
            <th>Fecha de publicación</th>
            <th>Numero de celular</th>
           
            
          </tr>
          </tfoot>
        <tbody>
        <?php foreach ($pdo->query("SELECT * FROM foro") as $fila) { ?> 
          <tr>
             
              <td>
              <?php echo $fila["nombre"] ?>
              </td>
              <td>
              <a href="opiniones.php?id=<?php echo $fila["id"] ?>"><?php echo $fila["titulo"] ?></a>
              </td>
              <td>
              <?php echo $fila["fecha"] ?>
              </td>
              <td>
              <?php echo $fila["numero"] ?>
              </td>
              
          </tr>
          <?php } ?>
        
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>

<!--aqui acaba el col-7-->
</div>
<div class="col-5">
    
   <h3 style="color:blue">CREA UN TEMA DE FORO Y HAZLE SABER A LA GENTE LO QUE LE SUCEDIO A TU MASCOTA </h3>
   <form action="registrar_tema.php" method="post">
   <hr>
   <br>
   <div>
        titulo:
        <input type="text" name="t" id="">
    </div>
    <br><hr>
     <div>
        Tema:
        <input type="text" name="c" id="">
    </div>
    <br><hr>
    <button class="btn btn-success" > Nuevo tema </button>
   </form>
</div> 
<div>
</div> 



<script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>


    
</body>
</html>