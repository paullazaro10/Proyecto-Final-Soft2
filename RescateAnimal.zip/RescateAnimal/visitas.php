<?php
    session_start();    
    if(!isset($_SESSION["correo"])){
        die("");

    } 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Document</title>
    
</head>
<body style="background-image: url(images/bacan.jpg);">
<?php include 'menu.php' ?>
<h3 style="margin:0 0 0 330px; color:black;font-weight: bold;font-size:40px">Resumen de las visistas de la web</h3>
<hr>
<div class="container">
<div class="row">
    <div class="col-6" style="color:rebeccapurple; font-size: 23px;font-weight: bold">  
<?php
echo "CANTIDAD DE VISITAS EN LA VENTANA DE ESTERILIZACION : ";
?>
<div style="color:red;font-size:40px">
<?php
include("visitas1.txt");
?>
</div>
<?php
echo "<hr>";
echo "CANTIDAD DE VISITAS EN LA VENTANA DEL FORO: ";
?>
<div style="color:red;font-size:40px">
<?php
include("visitas2.txt");
?>
</div>
<?php
echo "<hr>";
echo "CANTIDAD DE VISITAS EN LA VENTANA DE INICIO : ";
?>
<div style="color:red;font-size:40px">
<?php
include("visitas3.txt");
?>
</div>
<?php
echo "<hr>";
echo "CANTIDAD DE VISITAS EN LA VENTANA DE ADOPCION : ";
?>
<div style="color:red;font-size:40px">
<?php
include("visitas4.txt");
?>
</div>
<?php
echo "<hr>";
echo "CANTIDAD DE VISITAS EN LA VENTANA DEL PERFIL : ";
?>
<div style="color:red;font-size:40px">
<?php
include("visitas5.txt");
?>
</div>
<?php
echo "<hr>";

?>
<?php
$archivo1="visitas1.txt";
$archivo2="visitas2.txt";
$archivo3="visitas3.txt";
$archivo4="visitas4.txt";
$archivo5="visitas5.txt";

$abre1=fopen($archivo1, 'r'); 
$abre2=fopen($archivo2, 'r');
$abre3=fopen($archivo3, 'r');
$abre4=fopen($archivo4, 'r');
$abre5=fopen($archivo5, 'r');

$total1=fread($abre1, filesize($archivo1));
$total2=fread($abre2, filesize($archivo2));
$total3=fread($abre3, filesize($archivo3));
$total4=fread($abre4, filesize($archivo4));
$total5=fread($abre5, filesize($archivo5));

$visitas=$total1+$total2+$total3+$total4+$total5;

$por1=$total1*100/$visitas;
$por1=intval($por1,10);
$por2=$total2*100/$visitas;
$por2=intval($por2,10);
$por3=$total3*100/$visitas;
$por3=intval($por3,10);
$por4=$total4*100/$visitas;
$por4=intval($por4,10);
$por5=$total5*100/$visitas;
$por5=intval($por5,10);
?>

</div>  
<div class="col-6" style="font-weight: bold; font-size:30px;color:black">
<?php
echo "VENTANA DE ESTERILIZACION: $total1 visitas - $por1%";
echo "<img height=35 width=$por1% src=images/flecha.png></br>";
echo "<br>";
echo "VENTANA DE FORO: $total2 visitas - $por2%";
echo "<img height=35 width=$por2% src=images/flecha.png></br>";
echo "<br>";
echo "VENTANA DE INICIO: $total3 visitas - $por3%";
echo "<img height=35 width=$por3% src=images/flecha.png></br>";
echo "<br>";
echo "VENTANA DE ADOPCION: $total4 visitas - $por4%";
echo "<img height=35 width=$por4% src=images/flecha.png></br>";
echo "<br>";
echo "VENTANA DE PERFIL: $total5 visitas - $por5%";
echo "<img height=35 width=$por5% src=images/flecha.png></br>";
echo "<br>";

$todo=$por1+$por2+$por3+$por4+$por5;

echo "<hr size=2 color=ffffff width=30% align=left>";
echo "Total de visitas: <b>$visitas</b> de un <b>$todo %</b>";

?>
</div>
</div>  
</div>


</body>
</html>