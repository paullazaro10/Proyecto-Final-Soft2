<?php
$titulo= $_POST["t"];
$tema = $_POST["c"];

session_start();
$nombre=$_SESSION["nombre"];
$correo=$_SESSION["correo"];
$apellido=$_SESSION["apellido"];
$foto=$_SESSION["foto"];
$numero=$_SESSION["numero"];
$unio=$_SESSION["fecha"];

$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8","root","");
$q= ("INSERT INTO foro VALUES (NULL,'$nombre','$correo','$apellido',SYSDATE(),'$tema','$foto','$numero','$unio','$titulo')");
$pdo->query($q);

header("location:foro.php");
?>