<?php
    #Entrada
    $p=$_POST["contraseña"];
    $c=$_POST["correo"];
    #Proceso
    $validacion=false;
    $p=sha1("$p");
    $db= new PDO('mysql:host=localhost;dbname=mascotas;charset=utf8mb4','root','');
    $stmt = $db->query("SELECT * FROM usuario WHERE correo='$c' AND contraseña='$p'");
    $usuario=$stmt->fetchAll();
    if(count($usuario)==1){
        $validacion=true;
        session_start();
        $u=$usuario[0];
        $_SESSION["correo"]=$u["correo"];
        $_SESSION["nombre"]=$u["nombre"];
        $_SESSION["apellido"]=$u["apellido"];
        $_SESSION["foto"]=$u["foto"];
        $_SESSION["numero"]=$u["numero"];
        $_SESSION["fecha"]=$u["fecha"];

    }
    
    #Salida
    if($validacion){
        header("Location:index.php");
    }
    else{
        header("Location:login.php?error=1");
    }

?>