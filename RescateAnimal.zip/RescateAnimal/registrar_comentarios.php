<?php
$nombre = $_POST["n"];
$correo = $_POST["c"];
$comentarios = $_POST["m"];


$pdo = new PDO("mysql:host=localhost;dbname=mascotas;charset=utf8","root","");
$q= ("INSERT INTO comentarios VALUES (NULL, '$nombre','$comentarios','$correo',SYSDATE())");
$pdo->query($q);


header("location:lista.php");
?>