<?php 
    $id=$_GET["id"];
    $db= new PDO('mysql:host=localhost;dbname=mascotas;charset=utf8mb4','root','');
    $db->query("DELETE FROM mascota WHERE id='$id'");

    header("Location:lista.php");

?>